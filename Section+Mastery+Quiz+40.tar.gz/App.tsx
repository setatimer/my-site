import React, { useMemo, useState } from 'react';
import { ArrowRight, Check, ChevronLeft, Home, RotateCcw, ShieldCheck, Target, X } from 'lucide-react';

type Q = {
  id: number;
  prompt: string;
  kind: 'single' | 'multi';
  pickLabel: string;
  options: string[];
  correct: number[];
  explanation: string;
  tag: string;
};

const QUESTIONS: Q[] = [
  { id: 1, tag: 'Definition → Term', prompt: 'Which term means “two or more devices connected so they can communicate”?', kind: 'single', pickLabel: 'Choose one', options: ['Network', 'Host', 'Node', 'Server'], correct: [0], explanation: 'A network is two or more devices connected so they can communicate.' },
  { id: 2, tag: 'Term → Definition', prompt: 'What is a Node?', kind: 'single', pickLabel: 'Choose one', options: ['Any device or connection point on a network', 'A device that sends or receives network data', 'Hardware that connects a device to a network', 'The worldwide system of interconnected networks'], correct: [0], explanation: 'A node is any device or connection point on a network.' },
  { id: 3, tag: 'Term → Definition', prompt: 'Which term describes a device that sends or receives network data?', kind: 'single', pickLabel: 'Choose one', options: ['Client', 'Host', 'Packet Loss', 'Bandwidth'], correct: [1], explanation: 'A host is a device that sends or receives network data.' },
  { id: 4, tag: 'Scenario', prompt: 'A workstation asks a document service for a file so a user can open it. In this interaction, the workstation is acting as a…', kind: 'single', pickLabel: 'Choose one', options: ['Server', 'Client', 'NIC', 'WAN'], correct: [1], explanation: 'A client is a device or program that requests a service.' },
  { id: 5, tag: 'Term → Definition', prompt: 'Which term describes a computer or system that provides services to other devices?', kind: 'single', pickLabel: 'Choose one', options: ['Host', 'Client', 'Server', 'Node'], correct: [2], explanation: 'A server is a computer or system that provides services to other devices.' },
  { id: 6, tag: 'Term → Definition', prompt: 'What hardware connects a device to a network?', kind: 'single', pickLabel: 'Choose one', options: ['Throughput', 'Network Interface Card (NIC)', 'Extranet', 'Latency'], correct: [1], explanation: 'A Network Interface Card (NIC) is the hardware that connects a device to a network.' },
  { id: 7, tag: 'Scenario', prompt: 'A small office connects 12 computers and a shared printer in one building so they can share files. Which network type is this?', kind: 'single', pickLabel: 'Choose one', options: ['WAN', 'MAN', 'LAN', 'Internet'], correct: [2], explanation: 'A LAN connects devices in a limited area, such as a home or office.' },
  { id: 8, tag: 'Scenario', prompt: 'A company connects its offices in New York and Los Angeles so the two sites can work as one network. Which network type is this?', kind: 'single', pickLabel: 'Choose one', options: ['PAN', 'LAN', 'WLAN', 'WAN'], correct: [3], explanation: 'A WAN connects networks over large geographic distances.' },
  { id: 9, tag: 'Scenario', prompt: 'A home connects laptops and tablets without cables, using Wi-Fi. Which network type is this?', kind: 'single', pickLabel: 'Choose one', options: ['WLAN', 'PAN', 'VPN', 'MAN'], correct: [0], explanation: 'A WLAN is a LAN using wireless connections.' },
  { id: 10, tag: 'Scenario', prompt: 'A person’s phone connects to nearby earbuds and a smartwatch. Which network type best describes this?', kind: 'single', pickLabel: 'Choose one', options: ['MAN', 'WAN', 'PAN', 'LAN'], correct: [2], explanation: 'A PAN connects a person’s nearby devices.' },
  { id: 11, tag: 'Scenario', prompt: 'A university links buildings across a large campus that spans much of a city. Which network type is this?', kind: 'single', pickLabel: 'Choose one', options: ['PAN', 'MAN', 'WLAN', 'VPN'], correct: [1], explanation: 'A MAN spans a city or large campus area.' },
  { id: 12, tag: 'Scenario', prompt: 'An employee working from a hotel uses a protected connection across the public internet to reach company systems. What is this?', kind: 'single', pickLabel: 'Choose one', options: ['Intranet', 'Extranet', 'VPN', 'PAN'], correct: [2], explanation: 'A VPN creates a protected connection across another network.' },
  { id: 13, tag: 'Scenario', prompt: 'A company runs a private network for its own employees to share internal news and tools. No outside users are given access. What is this?', kind: 'single', pickLabel: 'Choose one', options: ['Internet', 'Intranet', 'Extranet', 'WAN'], correct: [1], explanation: 'An intranet is a private network used within an organization.' },
  { id: 14, tag: 'Scenario', prompt: 'A supplier is given limited access to a company’s private network to check orders. What is this kind of access called?', kind: 'single', pickLabel: 'Choose one', options: ['Intranet', 'Extranet', 'Internet', 'PAN'], correct: [1], explanation: 'An extranet is a private network that gives selected outside users or organizations access.' },
  { id: 15, tag: 'Term → Definition', prompt: 'Which term means “the worldwide system of interconnected networks”?', kind: 'single', pickLabel: 'Choose one', options: ['Intranet', 'LAN', 'Internet', 'VPN'], correct: [2], explanation: 'The Internet is the worldwide system of interconnected networks.' },
  { id: 16, tag: 'Term → Definition', prompt: 'What is Bandwidth?', kind: 'single', pickLabel: 'Choose one', options: ['The amount of data successfully transferred in a given time', 'The maximum data-carrying capacity of a connection', 'The time it takes data to travel from source to destination', 'Variation in packet delay or arrival time'], correct: [1], explanation: 'Bandwidth is the maximum data-carrying capacity of a connection.' },
  { id: 17, tag: 'Term → Definition', prompt: 'What is Throughput?', kind: 'single', pickLabel: 'Choose one', options: ['The maximum data-carrying capacity of a connection', 'Variation in packet delay or arrival time', 'The amount of data successfully transferred in a given time', 'A condition in which packets fail to reach their destination'], correct: [2], explanation: 'Throughput is the amount of data successfully transferred in a given time.' },
  { id: 18, tag: 'Term → Definition', prompt: 'What is Latency?', kind: 'single', pickLabel: 'Choose one', options: ['The time it takes data to travel from source to destination', 'The maximum data-carrying capacity of a connection', 'Variation in packet delay or arrival time', 'A protected connection across another network'], correct: [0], explanation: 'Latency is the time it takes data to travel from source to destination.' },
  { id: 19, tag: 'Term → Definition', prompt: 'What is Jitter?', kind: 'single', pickLabel: 'Choose one', options: ['Packets failing to reach their destination', 'The time it takes data to travel from source to destination', 'Variation in packet delay or arrival time', 'The amount of data successfully transferred in a given time'], correct: [2], explanation: 'Jitter is variation in packet delay or arrival time.' },
  { id: 20, tag: 'Term → Definition', prompt: 'What is Packet Loss?', kind: 'single', pickLabel: 'Choose one', options: ['Variation in packet delay or arrival time', 'A condition in which data packets fail to reach their destination', 'The maximum data-carrying capacity of a connection', 'A private network used within an organization'], correct: [1], explanation: 'Packet Loss is a condition in which data packets fail to reach their destination.' },
  { id: 21, tag: 'Multi-select · Pick 2', prompt: 'Which TWO are examples of a Host?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['A laptop sending an email', 'A printer receiving a print job', 'A length of cable with no device attached', 'An unused wall port with nothing connected'], correct: [0, 1], explanation: 'A host sends or receives network data, so the laptop and printer both qualify. A cable or empty port alone is not sending or receiving data.' },
  { id: 22, tag: 'Multi-select · Pick 3', prompt: 'Which THREE statements about Client and Server are true?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 3', options: ['A client is a device or program that requests a service', 'A server provides services to other devices', 'A server requests services from its clients', 'A client provides services to other devices', 'A client is a device or program'], correct: [0, 1, 4], explanation: 'A client requests a service, and a server provides services. The client is the requester, not the provider.' },
  { id: 23, tag: 'Multi-select · Pick 2', prompt: 'Which TWO describe a WAN?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['Connects networks over large geographic distances', 'Connects networks, not just devices in one room', 'Connects devices only in a limited area such as a home', 'Uses wireless connections only'], correct: [0, 1], explanation: 'A WAN connects networks over large geographic distances.' },
  { id: 24, tag: 'Multi-select · Pick 2', prompt: 'Which TWO statements about LAN and WLAN are true?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['A LAN connects devices in a limited area, such as a home or office', 'A WLAN is a LAN using wireless connections', 'A WLAN must use wired connections only', 'A LAN must be wireless'], correct: [0, 1], explanation: 'A LAN covers a limited area. A WLAN is that same kind of local network using wireless connections.' },
  { id: 25, tag: 'Multi-select · Pick 2', prompt: 'Which TWO statements about Intranet and Extranet are true?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['An intranet is a private network used within an organization', 'An extranet gives selected outside users or organizations access', 'An extranet is open to everyone on the Internet', 'An intranet gives outside users access to the private network'], correct: [0, 1], explanation: 'An intranet stays within an organization. An extranet extends limited private-network access to selected outsiders.' },
  { id: 26, tag: 'Multi-select · Pick 2', prompt: 'Which TWO statements about Bandwidth and Throughput are true?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['Bandwidth is the maximum data-carrying capacity of a connection', 'Throughput is the amount of data successfully transferred in a given time', 'Throughput is the maximum data-carrying capacity', 'Bandwidth is the amount of data successfully transferred'], correct: [0, 1], explanation: 'Bandwidth is the maximum capacity. Throughput is what is actually and successfully transferred in a given time.' },
  { id: 27, tag: 'Multi-select · Pick 3', prompt: 'Which THREE could be a Node?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 3', options: ['A router on a network', 'A connection point where a cable plugs in', 'A printer on a network', 'A device that has never been connected to any network'], correct: [0, 1, 2], explanation: 'A node is any device or connection point on a network, so the router, connection point, and printer all qualify.' },
  { id: 28, tag: 'Multi-select · Pick 2', prompt: 'Which TWO terms describe problems with how packets arrive?', kind: 'multi', pickLabel: 'Select ALL that apply — Pick 2', options: ['Jitter', 'Packet Loss', 'Bandwidth', 'Throughput'], correct: [0, 1], explanation: 'Jitter is variation in packet delay or arrival time. Packet Loss is packets failing to reach their destination.' },
  { id: 29, tag: 'Compare / Contrast', prompt: 'Which network type covers the larger geographic scope: LAN or WAN?', kind: 'single', pickLabel: 'Choose one', options: ['LAN', 'WAN', 'They cover exactly the same scope', 'PAN'], correct: [1], explanation: 'A LAN is limited to a home or office area, while a WAN connects networks over large geographic distances.' },
  { id: 30, tag: 'Compare / Contrast', prompt: 'What is the main difference between an Intranet and an Extranet?', kind: 'single', pickLabel: 'Choose one', options: ['An intranet is wireless and an extranet is wired', 'An intranet is for inside an organization; an extranet gives selected outsiders access', 'An extranet is worldwide and an intranet is citywide', 'There is no difference'], correct: [1], explanation: 'An intranet is used within an organization. An extranet gives selected outside users or organizations access.' },
  { id: 31, tag: 'Compare / Contrast', prompt: 'A plan advertises 500 Mbps maximum capacity. A speed test shows 420 Mbps actually and successfully transferred. What does the 420 Mbps represent?', kind: 'single', pickLabel: 'Choose one', options: ['Bandwidth', 'Latency', 'Throughput', 'Jitter'], correct: [2], explanation: 'Throughput is the amount successfully transferred in a given time. The 500 Mbps maximum is bandwidth.' },
  { id: 32, tag: 'Compare / Contrast', prompt: 'Which statement best distinguishes a Host from a Node?', kind: 'single', pickLabel: 'Choose one', options: ['A host is any connection point; a node must send data', 'A host sends or receives network data, while a node can be any device or connection point', 'A node is always a server; a host is always a client', 'They mean exactly the same thing'], correct: [1], explanation: 'A host sends or receives network data. A node is broader: any device or connection point on a network.' },
  { id: 33, tag: 'Which is NOT…', prompt: 'Which is NOT a network type defined by size or scope?', kind: 'single', pickLabel: 'Choose one', options: ['LAN', 'WAN', 'Network Interface Card (NIC)', 'MAN'], correct: [2], explanation: 'LAN, WAN, and MAN are network types. A NIC is hardware that connects a device to a network.' },
  { id: 34, tag: 'Which is NOT…', prompt: 'Which is NOT true about a VPN?', kind: 'single', pickLabel: 'Choose one', options: ['It creates a protected connection across another network', 'It can protect a connection across a public network', 'It makes a private network open to everyone', 'It creates a protected connection'], correct: [2], explanation: 'A VPN creates a protected connection across another network — it does not make a private network open to everyone.' },
  { id: 35, tag: 'Scenario', prompt: 'During a video call, several words never arrive at all and sentences have gaps. Which term best describes this?', kind: 'single', pickLabel: 'Choose one', options: ['Bandwidth', 'Packet Loss', 'Latency', 'WLAN'], correct: [1], explanation: 'Packet Loss is a condition in which data packets fail to reach their destination.' },
  { id: 36, tag: 'Scenario', prompt: 'In an online game, a player clicks and the action happens noticeably later because the data takes a long time to travel. Which term best describes this delay?', kind: 'single', pickLabel: 'Choose one', options: ['Jitter', 'Latency', 'Throughput', 'Packet Loss'], correct: [1], explanation: 'Latency is the time it takes data to travel from source to destination.' },
  { id: 37, tag: 'Scenario', prompt: 'On a voice call, speech keeps breaking up because packets arrive at uneven times — sometimes quickly, sometimes late. Which term best describes this?', kind: 'single', pickLabel: 'Choose one', options: ['Bandwidth', 'Jitter', 'Packet Loss', 'Server'], correct: [1], explanation: 'Jitter is variation in packet delay or arrival time.' },
  { id: 38, tag: 'Scenario', prompt: 'A desktop has no way to join the office network because it is missing the hardware that connects a device to a network. What is missing?', kind: 'single', pickLabel: 'Choose one', options: ['A server', 'A WAN', 'A Network Interface Card (NIC)', 'An extranet'], correct: [2], explanation: 'A NIC is the hardware that connects a device to a network.' },
  { id: 39, tag: 'Scenario', prompt: 'A school runs a private network for teachers and students only, with no access for outside users. What is this?', kind: 'single', pickLabel: 'Choose one', options: ['Extranet', 'Internet', 'Intranet', 'VPN'], correct: [2], explanation: 'An intranet is a private network used within an organization.' },
  { id: 40, tag: 'Which is NOT…', prompt: 'Which is NOT true about the Internet?', kind: 'single', pickLabel: 'Choose one', options: ['It is the worldwide system of interconnected networks', 'It connects networks around the world', 'It is a private network used only within one organization', 'It is made up of interconnected networks'], correct: [2], explanation: 'The Internet is the worldwide system of interconnected networks — not a private network used only within one organization.' },
];

const LETTERS = ['A', 'B', 'C', 'D', 'E'];

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function setsEqual(a: number[], b: number[]) {
  return a.length === b.length && a.every((v) => b.includes(v));
}

export default function App() {
  const [order, setOrder] = useState<number[]>(() => QUESTIONS.map((q) => q.id));
  const [pos, setPos] = useState(0);
  const [selected, setSelected] = useState<number[]>([]);
  const [checked, setChecked] = useState(false);
  const [answers, setAnswers] = useState<Record<number, { selected: number[]; correct: boolean }>>({});
  const [phase, setPhase] = useState<'quiz' | 'results' | 'review'>('quiz');
  const [reviewPos, setReviewPos] = useState(0);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const [notice, setNotice] = useState('');

  const currentId = order[pos];
  const current = QUESTIONS.find((q) => q.id === currentId)!;
  const answeredCount = Object.keys(answers).length;
  const correctCount = Object.values(answers).filter((a) => a.correct).length;
  const accuracy = answeredCount ? Math.round((correctCount / answeredCount) * 100) : 0;
  const wrongQs = useMemo(() => QUESTIONS.filter((q) => answers[q.id] && !answers[q.id].correct), [answers]);
  const reviewQ = wrongQs[reviewPos];

  const resetQuiz = (newOrder: number[]) => {
    setOrder(newOrder);
    setPos(0);
    setSelected([]);
    setChecked(false);
    setAnswers({});
    setPhase('quiz');
    setReviewPos(0);
    setConfirmRestart(false);
    setNotice('');
  };

  const toggleOption = (idx: number) => {
    if (checked) return;
    setSelected((prev) => {
      if (current.kind === 'single') return [idx];
      return prev.includes(idx) ? prev.filter((v) => v !== idx) : [...prev, idx];
    });
  };

  const checkAnswer = () => {
    if (!selected.length || checked) return;
    const isCorrect = setsEqual([...selected].sort(), [...current.correct].sort());
    setAnswers((prev) => ({ ...prev, [current.id]: { selected: [...selected], correct: isCorrect } }));
    setChecked(true);
  };

  const next = () => {
    setConfirmRestart(false);
    setNotice('');
    if (pos >= order.length - 1) {
      setPhase('results');
      return;
    }
    setPos(pos + 1);
    setSelected([]);
    setChecked(false);
  };

  const restart = () => {
    if (!confirmRestart) {
      setConfirmRestart(true);
      return;
    }
    resetQuiz(QUESTIONS.map((q) => q.id));
    setNotice('Quiz restarted from Question 1.');
  };

  const retake = () => {
    resetQuiz(shuffle(QUESTIONS.map((q) => q.id)));
    setNotice('Question order shuffled. Good luck — aim for 80% or higher.');
  };

  const startReview = () => {
    if (!wrongQs.length) return;
    setReviewPos(0);
    setPhase('review');
  };

  const isCorrectNow = checked && answers[current.id]?.correct;

  return (
    <div data-safe-area-inset-root style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100vh', background: 'var(--surface)' }} className="overflow-x-clip">
      {/* Header */}
      <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-30 text-white shadow-lg" >
        <div style={{ background: '#0A2A4D' }} className="px-4 py-4 sm:px-6">
          <div className="mx-auto max-w-[880px]">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-amber-300">CompTIA Network+ · 1 of 14</p>
                <h1 className="font-display mt-1 text-[clamp(1.25rem,5vw,1.9rem)] font-black leading-tight [overflow-wrap:anywhere]">Section 1 Mastery Quiz</h1>
                <p className="mt-1 text-[13px] font-semibold text-blue-100 sm:text-sm">Basic Networking Terminology · Mastery mode</p>
              </div>
              <div className="hidden shrink-0 items-center gap-2 rounded-full bg-white/10 px-3 py-2 text-xs font-bold sm:flex"><ShieldCheck size={16} /> Mastery: 80%</div>
            </div>

            {phase === 'quiz' && (
              <div className="mt-4">
                <div className="flex items-center justify-between gap-2 text-[12px] font-bold sm:text-[13px]">
                  <span>Question {pos + 1} / 40</span>
                  <span className="text-right">Correct: {correctCount} &nbsp;|&nbsp; Answered: {answeredCount} &nbsp;|&nbsp; Accuracy: {accuracy}%</span>
                </div>
                <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/20" aria-label={`Progress ${pos + 1} of 40`}>
                  <div className="h-full rounded-full bg-amber-400 transition-all" style={{ width: `${((pos + (checked ? 1 : 0)) / 40) * 100}%` }} />
                </div>
              </div>
            )}
          </div>
        </div>
        <div style={{ background: '#071E37' }} className="px-4 py-2 sm:px-6">
          <div className="mx-auto flex max-w-[880px] flex-wrap items-center justify-between gap-2 text-[12px] font-bold text-blue-100">
            <span>Section 1 - Basic Networking Terminology</span>
            <span className="rounded-full bg-white/10 px-2.5 py-1">{phase === 'results' ? 'Results' : phase === 'review' ? `Review · ${reviewPos + 1} / ${wrongQs.length}` : current.tag}</span>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[880px] px-4 pb-16 pt-5 sm:px-6">
        {notice && <div className="mb-4 rounded-xl border border-emerald-200 bg-[var(--green-bg)] px-4 py-3 text-sm font-semibold text-emerald-900" role="status">{notice}</div>}

        {phase === 'quiz' && (
          <section aria-label={`Question ${pos + 1}`}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-extrabold uppercase tracking-wider text-[#0A2A4D]">Question {pos + 1} <span className="text-slate-400">/ 40</span></p>
              <button onClick={restart} className="inline-flex items-center gap-1.5 rounded-full border border-slate-300 bg-white px-3 py-2 text-xs font-extrabold text-slate-700 shadow-sm hover:bg-slate-50">
                <RotateCcw size={14} /> {confirmRestart ? 'Tap again to confirm restart' : 'Restart'}
              </button>
            </div>

            <article className="mt-3 rounded-[22px] bg-[var(--card)] p-4 shadow-[0_10px_30px_rgba(10,42,77,0.10)] ring-1 ring-black/5 sm:p-6">
              <div className="flex items-start gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#0A2A4D] text-base font-black text-white">{pos + 1}</span>
                <div className="min-w-0">
                  <p className="text-[11px] font-extrabold uppercase tracking-widest text-amber-600">{current.tag} · {current.pickLabel}</p>
                  <h2 className="mt-1 text-[clamp(1.15rem,5vw,1.45rem)] font-extrabold leading-snug text-[var(--ink)] [overflow-wrap:anywhere]">{current.prompt}</h2>
                  <p className="mt-2 text-sm font-semibold text-[var(--muted)]">{current.kind === 'multi' ? 'Choose every correct option. Your answer must match exactly.' : 'Choose the one best answer.'}</p>
                </div>
              </div>

              <div className="mt-5 space-y-3" role={current.kind === 'multi' ? 'group' : 'radiogroup'} aria-label="Answer options">
                {current.options.map((opt, idx) => {
                  const isSelected = selected.includes(idx);
                  const isCorrectOpt = current.correct.includes(idx);
                  let cls = 'border-slate-200 bg-white hover:border-[#0A2A4D] hover:bg-blue-50/50';
                  let badgeCls = 'bg-slate-100 text-slate-700';
                  if (checked) {
                    if (isCorrectOpt) { cls = 'border-emerald-500 bg-[var(--green-bg)]'; badgeCls = 'bg-emerald-600 text-white'; }
                    else if (isSelected) { cls = 'border-red-400 bg-[var(--red-bg)]'; badgeCls = 'bg-red-600 text-white'; }
                    else { cls = 'border-slate-200 bg-slate-50 opacity-70'; }
                  } else if (isSelected) {
                    cls = 'border-[#0A2A4D] bg-blue-50 ring-2 ring-[#0A2A4D]/20';
                    badgeCls = 'bg-[#0A2A4D] text-white';
                  }
                  return (
                    <button key={idx} type="button" onClick={() => toggleOption(idx)} disabled={checked} aria-checked={isSelected} role={current.kind === 'multi' ? 'checkbox' : 'radio'} className={`flex w-full items-start gap-3 rounded-2xl border-2 px-3 py-3.5 text-left transition sm:px-4 sm:py-4 ${cls}`}>
                      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-black ${badgeCls}`}>{LETTERS[idx]}</span>
                      <span className="min-w-0 flex-1 pt-1 text-[15px] font-bold leading-snug text-[var(--ink)] [overflow-wrap:anywhere] sm:text-base">{opt}</span>
                      <span className="mt-1 shrink-0">
                        {checked && isCorrectOpt && <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-white"><Check size={15} /></span>}
                        {checked && isSelected && !isCorrectOpt && <span className="flex h-6 w-6 items-center justify-center rounded-full bg-red-600 text-white"><X size={15} /></span>}
                        {!checked && isSelected && <span className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-[#0A2A4D] bg-[#0A2A4D] text-white"><Check size={14} /></span>}
                      </span>
                    </button>
                  );
                })}
              </div>

              {checked && (
                <div className={`mt-5 rounded-2xl border-2 p-4 ${isCorrectNow ? 'border-emerald-200 bg-[var(--green-bg)]' : 'border-amber-200 bg-[var(--amber-bg)]'}`} role="status">
                  <p className="text-base font-black">{isCorrectNow ? '✓ Correct!' : 'Not quite.'}</p>
                  <p className="mt-1 text-sm font-semibold leading-relaxed text-[var(--ink)] [overflow-wrap:anywhere]">{current.explanation}</p>
                  {!isCorrectNow && <p className="mt-2 text-sm font-bold">Correct answer: {current.correct.map((i) => `${LETTERS[i]} — ${current.options[i]}`).join(' · ')}</p>}
                </div>
              )}

              <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-end">
                {!checked ? (
                  <button onClick={checkAnswer} disabled={!selected.length} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0A2A4D] px-5 py-3.5 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-40 sm:w-auto">
                    Check Answer <Check size={17} />
                  </button>
                ) : (
                  <button onClick={next} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0A2A4D] px-5 py-3.5 text-sm font-extrabold text-white sm:w-auto">
                    {pos === 39 ? 'See Results' : 'Next Question'} <ArrowRight size={17} />
                  </button>
                )}
              </div>
              <p className="mt-3 text-center text-xs font-semibold text-slate-400">Mastery target: 32 / 40 correct (80%). No term table — just the quiz.</p>
            </article>
          </section>
        )}

        {phase === 'results' && (
          <section>
            <div className="overflow-hidden rounded-[24px] bg-[#0A2A4D] p-5 text-white shadow-xl sm:p-7">
              <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-amber-300">Section 1 · Results</p>
              <h2 className="font-display mt-2 text-[clamp(2rem,10vw,3.4rem)] font-black leading-none">{correctCount} / 40</h2>
              <p className="mt-2 text-lg font-bold">{accuracy}% · {correctCount >= 32 ? 'Mastery achieved 🎉' : 'Keep going — mastery is 80%'}</p>
              <p className="mt-3 max-w-[620px] text-sm leading-relaxed text-blue-100 [overflow-wrap:anywhere]">{correctCount >= 32 ? 'You hit the mastery bar for Basic Networking Terminology. You can retake to lock it in or review the ones you missed.' : 'You need 32 / 40 to pass at 80%. Review the questions below, then retake — the order will shuffle.'}</p>
              <div className="mt-4 flex h-3 overflow-hidden rounded-full bg-white/20"><div className="h-full rounded-full bg-amber-400" style={{ width: `${accuracy}%` }} /></div>
              <div className="mt-5 flex flex-col gap-2 sm:flex-row">
                <button onClick={retake} className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-400 px-5 py-3.5 text-sm font-black text-[#0A2A4D]"><RotateCcw size={16} /> Retake Quiz</button>
                <button onClick={startReview} disabled={!wrongQs.length} className="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3.5 text-sm font-extrabold text-[#0A2A4D] disabled:opacity-50"><Target size={16} /> Review Wrong Answers ({wrongQs.length})</button>
              </div>
            </div>

            <h3 className="mt-6 text-lg font-black">Breakdown — questions to review</h3>
            {wrongQs.length === 0 ? (
              <p className="mt-3 rounded-2xl bg-[var(--card)] p-5 font-semibold">Perfect run. No wrong answers to review.</p>
            ) : (
              <div className="mt-3 space-y-3">
                {wrongQs.map((q) => {
                  const ans = answers[q.id];
                  return (
                    <article key={q.id} className="rounded-2xl bg-[var(--card)] p-4 shadow-sm ring-1 ring-black/5 sm:p-5">
                      <p className="text-xs font-extrabold uppercase tracking-wider text-red-600">Question {q.id} · {q.tag}</p>
                      <p className="mt-1 font-bold leading-snug [overflow-wrap:anywhere]">{q.prompt}</p>
                      <p className="mt-2 text-sm text-[var(--muted)]">Your answer: <span className="font-bold text-red-600">{ans.selected.map((i) => `${LETTERS[i]} — ${q.options[i]}`).join(' · ') || 'No answer'}</span></p>
                      <p className="mt-1 text-sm">Correct answer: <span className="font-bold text-emerald-700">{q.correct.map((i) => `${LETTERS[i]} — ${q.options[i]}`).join(' · ')}</span></p>
                      <p className="mt-2 text-sm font-semibold leading-relaxed [overflow-wrap:anywhere]">{q.explanation}</p>
                    </article>
                  );
                })}
              </div>
            )}
            <button onClick={() => resetQuiz(QUESTIONS.map((q) => q.id))} className="mt-6 inline-flex items-center gap-2 rounded-xl border px-4 py-3 text-sm font-bold"><Home size={16} /> Back to Question 1</button>
          </section>
        )}

        {phase === 'review' && reviewQ && (
          <section>
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-extrabold uppercase tracking-wider text-[#0A2A4D]">Review {reviewPos + 1} / {wrongQs.length}</p>
              <button onClick={() => setPhase('results')} className="rounded-full border bg-white px-3 py-2 text-xs font-extrabold">Back to Results</button>
            </div>
            <article className="mt-3 rounded-[22px] bg-[var(--card)] p-4 shadow sm:p-6">
              <p className="text-xs font-extrabold uppercase tracking-widest text-amber-600">{reviewQ.tag}</p>
              <h2 className="mt-1 text-xl font-extrabold leading-snug [overflow-wrap:anywhere]">{reviewQ.prompt}</h2>
              <div className="mt-4 space-y-2">
                {reviewQ.options.map((opt, idx) => {
                  const isCorrectOpt = reviewQ.correct.includes(idx);
                  const wasPicked = answers[reviewQ.id]?.selected.includes(idx);
                  return (
                    <div key={idx} className={`flex items-start gap-3 rounded-xl border-2 px-3 py-3 ${isCorrectOpt ? 'border-emerald-500 bg-[var(--green-bg)]' : wasPicked ? 'border-red-300 bg-[var(--red-bg)]' : 'border-slate-200'}`}>
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-black">{LETTERS[idx]}</span>
                      <span className="flex-1 pt-0.5 text-sm font-bold leading-snug [overflow-wrap:anywhere]">{opt}</span>
                      {isCorrectOpt && <span className="text-xs font-black text-emerald-700">CORRECT</span>}
                      {wasPicked && !isCorrectOpt && <span className="text-xs font-black text-red-600">YOUR PICK</span>}
                    </div>
                  );
                })}
              </div>
              <div className="mt-4 rounded-xl bg-[var(--amber-bg)] p-4 text-sm font-semibold leading-relaxed [overflow-wrap:anywhere]">{reviewQ.explanation}</div>
              <div className="mt-5 flex gap-2">
                <button disabled={reviewPos === 0} onClick={() => setReviewPos(reviewPos - 1)} className="inline-flex items-center gap-1 rounded-xl border px-4 py-3 text-sm font-bold disabled:opacity-40"><ChevronLeft size={16} /> Previous</button>
                {reviewPos < wrongQs.length - 1 ? (
                  <button onClick={() => setReviewPos(reviewPos + 1)} className="inline-flex flex-1 items-center justify-center gap-1 rounded-xl bg-[#0A2A4D] px-4 py-3 text-sm font-extrabold text-white">Next Wrong <ArrowRight size={16} /></button>
                ) : (
                  <button onClick={retake} className="inline-flex flex-1 items-center justify-center gap-1 rounded-xl bg-amber-400 px-4 py-3 text-sm font-black text-[#0A2A4D]"><RotateCcw size={16} /> Retake Quiz</button>
                )}
              </div>
            </article>
          </section>
        )}
      </main>
    </div>
  );
}
